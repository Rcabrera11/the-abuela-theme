# The Abuela — Shopify Theme 🧉

Custom Dawn-based theme for The Abuela yerba mate store.

## What's inside
- Yerba color palette (5 schemes: cream, greens, amber)
- Home: hero, ritual, promises, products, health, honesty, gift banner, closing
- Product pages: education-first layout (learn the yerba → then buy)
- Page templates: about (with brand moat), shipping, family
- Header (dark green) + announcement bar (amber) + footer (dark green)

## Connect to Shopify
Shopify admin → Online Store → Themes → Add theme → **Connect from GitHub**
→ authorize → pick this repo, branch `main`.

After connecting, every push to `main` updates the theme automatically.

## Manual steps (GitHub can't do these)
1. Products: import `the_abuela_products.csv` via Products → Import
2. Pages: create About / Shipping / Join the family in Pages → Add page,
   assign templates `about` / `shipping` / `family`
3. Navigation: add the pages to Main menu
4. Photos: upload via theme editor (hero, ritual, gift banner) and per product
5. Payments, shipping zones, plan, remove password → launch
